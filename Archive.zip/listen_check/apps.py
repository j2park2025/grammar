from django.apps import AppConfig


class ListenCheckConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'listen_check'
